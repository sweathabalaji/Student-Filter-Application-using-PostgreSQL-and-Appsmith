
import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { getUniqueSchools, getUniqueClasses, getUniqueSections } from '@/services/databaseService';

interface FilterControlsProps {
  schoolName: string | null;
  className: string | null;
  section: string | null;
  onSchoolChange: (value: string | null) => void;
  onClassChange: (value: string | null) => void;
  onSectionChange: (value: string | null) => void;
  onFilter: () => void;
  onReset: () => void;
}

const FilterControls: React.FC<FilterControlsProps> = ({
  schoolName,
  className,
  section,
  onSchoolChange,
  onClassChange,
  onSectionChange,
  onFilter,
  onReset,
}) => {
  const schools = getUniqueSchools();
  const classes = getUniqueClasses();
  const sections = getUniqueSections();

  return (
    <div className="bg-white p-6 rounded-lg shadow-md space-y-4 md:space-y-0 md:flex md:items-end md:space-x-4">
      <div className="flex-1">
        <label htmlFor="school-dropdown" className="block font-medium text-sm text-gray-700 mb-1">
          School Name
        </label>
        <Select
          value={schoolName || "all_schools"}
          onValueChange={(value) => onSchoolChange(value === "all_schools" ? null : value)}
        >
          <SelectTrigger id="school-dropdown" className="w-full">
            <SelectValue placeholder="Select school" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_schools">All Schools</SelectItem>
            {schools.map((school) => (
              <SelectItem key={school} value={school}>
                {school}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex-1">
        <label htmlFor="class-dropdown" className="block font-medium text-sm text-gray-700 mb-1">
          Class
        </label>
        <Select
          value={className || "all_classes"}
          onValueChange={(value) => onClassChange(value === "all_classes" ? null : value)}
        >
          <SelectTrigger id="class-dropdown" className="w-full">
            <SelectValue placeholder="Select class" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_classes">All Classes</SelectItem>
            {classes.map((cls) => (
              <SelectItem key={cls} value={cls}>
                {cls}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex-1">
        <label htmlFor="section-dropdown" className="block font-medium text-sm text-gray-700 mb-1">
          Section
        </label>
        <Select
          value={section || "all_sections"}
          onValueChange={(value) => onSectionChange(value === "all_sections" ? null : value)}
        >
          <SelectTrigger id="section-dropdown" className="w-full">
            <SelectValue placeholder="Select section" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_sections">All Sections</SelectItem>
            {sections.map((sec) => (
              <SelectItem key={sec} value={sec}>
                {sec}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex space-x-2">
        <Button onClick={onFilter} className="bg-blue-600 hover:bg-blue-700">
          Filter Data
        </Button>
        <Button onClick={onReset} variant="outline">
          Reset
        </Button>
      </div>
    </div>
  );
};

export default FilterControls;
