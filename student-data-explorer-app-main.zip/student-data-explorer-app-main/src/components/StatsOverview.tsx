
import React from 'react';
import { Student } from '@/services/databaseService';

interface StatsOverviewProps {
  filteredStudents: Student[];
  totalStudents: number;
}

const StatsOverview: React.FC<StatsOverviewProps> = ({ filteredStudents, totalStudents }) => {
  const uniqueSchools = new Set(filteredStudents.map(s => s.school_name)).size;
  const uniqueClasses = new Set(filteredStudents.map(s => s.class)).size;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-blue-500">
        <div className="text-sm font-medium text-gray-500">Students Showing</div>
        <div className="mt-1 flex items-baseline">
          <div className="text-2xl font-semibold text-gray-900">{filteredStudents.length}</div>
          <div className="ml-2 text-sm text-gray-500">/ {totalStudents} total</div>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-green-500">
        <div className="text-sm font-medium text-gray-500">Schools</div>
        <div className="mt-1 text-2xl font-semibold text-gray-900">{uniqueSchools}</div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-md border-l-4 border-purple-500">
        <div className="text-sm font-medium text-gray-500">Classes</div>
        <div className="mt-1 text-2xl font-semibold text-gray-900">{uniqueClasses}</div>
      </div>
    </div>
  );
};

export default StatsOverview;
