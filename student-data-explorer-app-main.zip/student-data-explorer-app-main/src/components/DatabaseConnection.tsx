
import React from 'react';
import { Badge } from '@/components/ui/badge';

const DatabaseConnection = () => {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2 text-sm">
      <div className="flex items-center gap-2">
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 px-2">
          Connected
        </Badge>
        <span className="text-gray-500 text-xs">PostgreSQL DB on Render</span>
      </div>
      <div className="text-gray-400 text-xs font-mono truncate">
        postgres://admin:••••••••@student-database.postgres.render.com:5432/students
      </div>
    </div>
  );
};

export default DatabaseConnection;
