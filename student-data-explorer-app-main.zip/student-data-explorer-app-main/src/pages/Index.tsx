
import React, { useState, useEffect } from 'react';
import { filterStudents, studentData, Student } from '@/services/databaseService';
import { toast } from '@/components/ui/use-toast';
import FilterControls from '@/components/FilterControls';
import StudentsTable from '@/components/StudentsTable';
import Header from '@/components/Header';
import DatabaseConnection from '@/components/DatabaseConnection';
import StatsOverview from '@/components/StatsOverview';

const Index = () => {
  const [schoolName, setSchoolName] = useState<string | null>(null);
  const [className, setClassName] = useState<string | null>(null);
  const [section, setSection] = useState<string | null>(null);
  const [students, setStudents] = useState<Student[]>(studentData);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleFilter = () => {
    setIsLoading(true);
    
    // Simulate database query delay
    setTimeout(() => {
      const filtered = filterStudents(schoolName, className, section);
      setStudents(filtered);
      setIsLoading(false);
      
      toast({
        title: "Filters Applied",
        description: `Found ${filtered.length} student${filtered.length !== 1 ? 's' : ''}`,
      });
    }, 600);
  };

  const handleReset = () => {
    setSchoolName(null);
    setClassName(null);
    setSection(null);
    setStudents(studentData);
    toast({
      title: "Filters Reset",
      description: "Showing all students",
    });
  };

  // Initial load
  useEffect(() => {
    handleFilter();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Student Database</h2>
          <DatabaseConnection />
          <StatsOverview 
            filteredStudents={students} 
            totalStudents={studentData.length} 
          />
          
          <div className="mb-6">
            <FilterControls
              schoolName={schoolName}
              className={className}
              section={section}
              onSchoolChange={setSchoolName}
              onClassChange={setClassName}
              onSectionChange={setSection}
              onFilter={handleFilter}
              onReset={handleReset}
            />
          </div>
          
          <StudentsTable students={students} isLoading={isLoading} />
        </div>
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            Student Database Management System - Simulated PostgreSQL Interface
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
