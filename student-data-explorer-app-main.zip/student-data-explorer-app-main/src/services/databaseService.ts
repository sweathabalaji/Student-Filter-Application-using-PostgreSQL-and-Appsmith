
// Sample student data (simulating PostgreSQL database)
export interface Student {
  id: number;
  school_name: string;
  class: string;
  section: string;
  student_name: string;
  roll_number: number;
}

export const studentData: Student[] = [
  { id: 1, school_name: "Green Valley School", class: "10", section: "A", student_name: "John Doe", roll_number: 101 },
  { id: 2, school_name: "Green Valley School", class: "10", section: "B", student_name: "Jane Smith", roll_number: 102 },
  { id: 3, school_name: "Sunrise Academy", class: "9", section: "A", student_name: "Alice Brown", roll_number: 201 },
  { id: 4, school_name: "Sunrise Academy", class: "9", section: "B", student_name: "Bob Wilson", roll_number: 202 },
  { id: 5, school_name: "Green Valley School", class: "10", section: "A", student_name: "Mary Johnson", roll_number: 103 },
  { id: 6, school_name: "Sunrise Academy", class: "10", section: "A", student_name: "Tom Clark", roll_number: 203 },
];

// Get unique values for each filter type
export const getUniqueSchools = (): string[] => {
  return [...new Set(studentData.map((student) => student.school_name))];
};

export const getUniqueClasses = (): string[] => {
  return [...new Set(studentData.map((student) => student.class))];
};

export const getUniqueSections = (): string[] => {
  return [...new Set(studentData.map((student) => student.section))];
};

// Filter students based on selected filters
export const filterStudents = (
  schoolName: string | null,
  className: string | null,
  section: string | null
): Student[] => {
  return studentData.filter((student) => {
    const matchesSchool = !schoolName || student.school_name === schoolName;
    const matchesClass = !className || student.class === className;
    const matchesSection = !section || student.section === section;
    
    return matchesSchool && matchesClass && matchesSection;
  });
};
